#![macro_use]
use middle::analysis::ast::*;
use ast::Expression::*;


pub struct UselessChaining<'a: 'c, 'b: 'a, 'c>
{
  grammar: &'c AGrammar<'a, 'b>
}

impl <'a, 'b, 'c> UselessChaining<'a, 'b, 'c>
{
  pub fn analyse(grammar: AGrammar<'a, 'b>) -> Partial<AGrammar<'a, 'b>> {
      let mut cpt_not_not = 0;
      let mut cpt_and_and = 0;
      let mut cpt_not_and = 0;
      let mut cpt_and_not = 0;
      let mut cpt_oom_oom = 0;
      let mut cpt_oom_zom = 0;

      for expr in &grammar.exprs {

          match expr {
              &StrLiteral(_) => println!("\nStrLiteral"),
              &AnySingleChar => println!("AnySingleChar"),
              &CharacterClass(_) => println!("CharacterClass"),
              &NonTerminalSymbol(_) => println!("NonTerminalSymbol -> à évaluer en terminal symbol"),
              &Sequence(_) => println!("Sequence"),
              &Choice(_) => println!("Choice"),
              &ZeroOrMore(_) => println!("ZeroOrMore"),
              &OneOrMore(_) => println!("OneOrMore"),
              &ZeroOrOne(_) => println!("ZeroOrOne"),
              &NotPredicate(_) => println!("NotPredicate"),
              &AndPredicate(_) => println!("AndPredicate"),
              &SemanticAction(_, _) => println!("SemanticAction"),
              &TypeAscription(_, _) => println!("TypeAscription"),
              &SpannedExpr(_) => println!("SpannedExpr"),
          }

          match expr {
              &AndPredicate(_) => {
                  if cpt_and_and+1>=2 {
                      grammar.warn(format!("Detected useless chaining: &(&e) \nHelp: &(&e) ~ &e"));
                      cpt_and_and=0;
                  }
                  if cpt_not_and+1>=2 {
                      grammar.warn(format!("Detected useless chaining: !(&e) \nHelp: !(&e) ~ !e"));
                  }
                  cpt_and_and+=1;
                  cpt_and_not+=1;
                  cpt_not_not = 0;
                  cpt_not_and = 0;
                  cpt_oom_oom = 0;
                  cpt_oom_zom = 0;
              }
              &NotPredicate(_) => {
                  if cpt_not_not+1>=2 {
                      grammar.warn(format!("Detected useless chaining: !(!e) \nHelp: !(!e) ~ &e"));
                      cpt_not_not=0;
                  }
                  if cpt_and_not+1>=2 {
                      grammar.warn(format!("Detected useless chaining: &(!e) \nHelp: &(!e) ~ !e"));
                  }
                  cpt_not_not+=1;
                  cpt_not_and+=1;
                  cpt_and_and = 0;
                  cpt_and_not = 0;
                  cpt_oom_oom = 0;
                  cpt_oom_zom = 0;
              }
              &OneOrMore(_) => {
                  if cpt_oom_oom+1>=2 {
                      grammar.warn(format!("Detected useless chaining: (e+)+ \nHelp: (e+)+ ~ e+"));
                      cpt_oom_oom=0;
                  }
                  cpt_oom_oom+=1;
                  cpt_oom_zom+=1;
                  cpt_not_not = 0;
                  cpt_and_and = 0;
                  cpt_not_and = 0;
                  cpt_and_not = 0;
              }
              &ZeroOrMore(_) => {
                  if cpt_oom_zom+1>=2 {
                      grammar.warn(format!("Detected useless chaining: (e+)* \nHelp: (e+)* ~ e+"));
                  }
                  cpt_not_not = 0;
                  cpt_and_and = 0;
                  cpt_not_and = 0;
                  cpt_and_not = 0;
                  cpt_oom_oom = 0;
                  cpt_oom_zom = 0;
              }
              _ => {
                  cpt_not_not = 0;
                  cpt_and_and = 0;
                  cpt_not_and = 0;
                  cpt_and_not = 0;
                  cpt_oom_oom = 0;
                  cpt_oom_zom = 0;
              }
          }
      }
      Partial::Nothing
  }
}
