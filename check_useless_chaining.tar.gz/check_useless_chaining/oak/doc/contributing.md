% Contributing

A library writer always has the secret hope that its library will be used by thousands. An even more secret hope is that some users would become *contributors*!

If you want to contribute, please contact me by email (ptalbot@hyc.io) –I usually respond very quickly– to discuss about a project suited to your ambitions and needs. I'm willing to mentor you until you feel confident with the code and I'm open to suggestions :-)

<!-- Anyways, the first step is to read this user manual. -->

<!-- There is also a incomplete [developer documentation](http://hyc.io/rust-lib/oak-dev/oak/index.html). -->
